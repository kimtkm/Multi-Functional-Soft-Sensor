import serial
import time
import sys

import numpy as np
import tensorflow as tf
from datetime import datetime
import os
from Sensor_Model import Sensor_Model

import socket

## Global Variables ##
data = []
dataArduino = []

## Initialization ##
serArduino = serial.Serial('COM13', 115200, timeout=0.5)
print("Connecting Serials.", end="", flush=True)
for i in range(9):
	print(".",end="",flush=True)
	time.sleep(1) # Pause for serials to open

## Configure load cell settings
time.sleep(0.5) # Pause for initialization

## Flush serial buffer
serArduino.reset_input_buffer()

outputFile = open('output.csv', 'w') # Open output file

## Learning model
model = Sensor_Model()

## UDP
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
local_ip_port = ('127.0.0.1', 9800)
remote_ip_port = ('127.0.0.1', 9906)
sock.bind(local_ip_port)


with tf.Session() as sess:
        ckpt_dir = './ckpt/'
        ckpt_path_location = ckpt_dir + 'XXX' + '.ckpt'
        saver = tf.train.Saver()
        saver.restore(sess, ckpt_path_location)

        startTime = time.time()

        while(True):
                serArduino.write(b'A')
                
                dataArduino = serArduino.readline().decode("utf-8").split(",") # Assume Arduino sends in csv format
                dataArduino = [float(datum) for datum in dataArduino if datum]	# Remove null entries and convert to float
                
                if(len(dataArduino)!=4):
                        serArduino.reset_input_buffer() # Flush serial buffer
                        
                        continue
                else:
                        x_data = np.array([[dataArduino[0], dataArduino[1], dataArduino[2], dataArduino[3]]])
                        x_data_ = np.expand_dims(x_data[0,[0,1,2]], axis=0)
                        pred = sess.run(model.Out, feed_dict={model.X: x_data_})
                        y =  np.argmax(pred, axis=1)
                        data = np.hstack([x_data[0,0], x_data[0,1], x_data[0,2], x_data[0,3], y])
                        outputFile.write(",".join(str(datum) for datum in data)) # Write data to file in csv
                        outputFile.write("\n")
                        i=i+1
                        print((i)/(time.time()-startTime))

                        sendData = "s"+","+str(dataArduino[0])+","+str(dataArduino[1])+","+str(dataArduino[2])+","+str(y.item())+","+"\n"
                        sock.sendto(sendData.encode(), remote_ip_port)                        
                                
                print(data)
