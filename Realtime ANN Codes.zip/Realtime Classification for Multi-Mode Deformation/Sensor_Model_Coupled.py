import numpy as np
import tensorflow as tf
import os
import math

class Sensor_Model_Coupled(object):
    def __init__(self):
        self.X = tf.placeholder(tf.float32, [None, 3])
        self.Y = tf.placeholder(tf.int32, [None, 1])
        self.Y_onehot = tf.one_hot(self.Y, 6)
        
        self.Hidden1 = tf.contrib.layers.fully_connected(self.X, 64, activation_fn = tf.nn.leaky_relu, 
                                                                 weights_initializer = tf.contrib.layers.xavier_initializer())
        self.Hidden2 = tf.contrib.layers.fully_connected(self.Hidden1, 32, activation_fn = tf.nn.leaky_relu, 
                                                                 weights_initializer = tf.contrib.layers.xavier_initializer())
        self.Out = tf.contrib.layers.fully_connected(self.Hidden2, 6, activation_fn = tf.nn.softmax, 
                                                                 weights_initializer = tf.contrib.layers.xavier_initializer())
        self.Cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=self.Out, labels=self.Y_onehot))
        self.lr = 1e-4 #learning rate
        self.global_step = tf.Variable(0, trainable=False)
        self.decay = tf.train.exponential_decay(self.lr, self.global_step, 100, 0.94, staircase = True)
        self.Optimizer = tf.train.AdamOptimizer(self.decay, name='Adam').minimize(self.Cost)

