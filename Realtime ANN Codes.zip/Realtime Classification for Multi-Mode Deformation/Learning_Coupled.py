import numpy as np
import tensorflow as tf
from datetime import datetime
import os
from Sensor_Model_Coupled import Sensor_Model_Coupled

startTime = datetime.now()
xy = np.loadtxt('XXX.csv', delimiter=',', dtype=np.float32)
x_Training_data = xy[:, [0, 1, 2]]
y_Training_data = xy[:, [-1]]
y_Training_data = np.array(y_Training_data, np.int32)

xy = np.loadtxt('XXX.csv', delimiter=',', dtype=np.float32)
x_Test_data = xy[:, [0, 1, 2]]
y_Test_data = xy[:, [-1]]
y_Test_data = np.array(y_Test_data, np.int32)

minibatch_size = 256

tf.reset_default_graph()
model = Sensor_Model_Coupled()
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for epoch in range(5001):
        cost = 0
        for i in range((int)((np.shape(x_Training_data)[0])/minibatch_size)):
            x_batch = x_Training_data[i*minibatch_size:(i+1)*minibatch_size,:]
            y_batch = y_Training_data[i*minibatch_size:(i+1)*minibatch_size,:]
            _, c = sess.run([model.Optimizer, model.Cost], feed_dict = {model.X: x_batch, model.Y:y_batch})
            cost = cost + c
        cost = cost / (int)(np.shape(x_Training_data)[0]/minibatch_size)
        if epoch >= 0:
            print("Training","Epoch:",epoch,"isforce:",cost)
    ckpt_dir = './ckpt/'
    if not os.path.exists(ckpt_dir):
        os.makedirs(ckpt_dir)
    ckpt_path = ckpt_dir + 'XXX' + '.ckpt'
    saver = tf.train.Saver()
    saver.save(sess, ckpt_path)

endTime = datetime.now()
print("Training Done!")
print(endTime-startTime)
